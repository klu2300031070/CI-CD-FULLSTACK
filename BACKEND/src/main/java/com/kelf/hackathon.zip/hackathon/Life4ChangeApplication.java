package com.kelf.hackathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Life4ChangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Life4ChangeApplication.class, args);
		System.out.println("my project is running");
	}

}
